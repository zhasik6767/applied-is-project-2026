from contextlib import asynccontextmanager

from fastapi import FastAPI

from app.api.routes import router
from app.database.session import init_db


@asynccontextmanager
async def lifespan(app):
    init_db()
    yield


app = FastAPI(title="ИС учёта товаров на складе", version="1.0.0", lifespan=lifespan)
app.include_router(router)


@app.get("/", tags=["Проверка"])
def health():
    return {"status": "ok", "project": "warehouse", "lab": 1}
