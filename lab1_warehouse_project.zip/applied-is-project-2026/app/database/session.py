import os
from pathlib import Path

from sqlalchemy import event
from sqlmodel import Session, SQLModel, create_engine

ROOT = Path(__file__).resolve().parents[2]
DB_PATH = Path(os.getenv("WAREHOUSE_DB_PATH", str(ROOT / "warehouse.db"))).resolve()
engine = create_engine(
    "sqlite:///" + DB_PATH.as_posix(),
    connect_args={"check_same_thread": False, "timeout": 15},
)


@event.listens_for(engine, "connect")
def enable_foreign_keys(connection, _):
    connection.execute("PRAGMA foreign_keys=ON")


def init_db():
    from app import models  # Регистрация всех таблиц в metadata.
    SQLModel.metadata.create_all(engine)


def get_session():
    with Session(engine) as session:
        yield session
