"""Четыре таблицы, соответствующие ER-диаграмме в docs/."""
from datetime import datetime, timezone

from sqlalchemy import CheckConstraint
from sqlmodel import Field, Relationship, SQLModel


class Category(SQLModel, table=True):
    id: int | None = Field(default=None, primary_key=True)
    name: str = Field(index=True, unique=True, max_length=80)
    products: list["Product"] = Relationship(back_populates="category")


class Supplier(SQLModel, table=True):
    id: int | None = Field(default=None, primary_key=True)
    name: str = Field(index=True, unique=True, max_length=120)
    contact: str = Field(default="", max_length=120)
    products: list["Product"] = Relationship(back_populates="supplier")


class Product(SQLModel, table=True):
    __table_args__ = (CheckConstraint("min_stock >= 0"),)
    id: int | None = Field(default=None, primary_key=True)
    name: str = Field(index=True, max_length=120)
    sku: str = Field(index=True, unique=True, max_length=40)
    category_id: int = Field(foreign_key="category.id")
    supplier_id: int = Field(foreign_key="supplier.id")
    min_stock: int = Field(default=5, ge=0)
    category: Category = Relationship(back_populates="products")
    supplier: Supplier = Relationship(back_populates="products")
    movements: list["Movement"] = Relationship(back_populates="product")


class Movement(SQLModel, table=True):
    __table_args__ = (CheckConstraint("delta != 0"),)
    id: int | None = Field(default=None, primary_key=True)
    product_id: int = Field(foreign_key="product.id", index=True)
    delta: int  # Приход положительный, расход отрицательный.
    note: str = Field(default="", max_length=200)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    product: Product = Relationship(back_populates="movements")
