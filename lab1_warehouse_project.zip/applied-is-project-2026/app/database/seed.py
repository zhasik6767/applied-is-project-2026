"""Демонстрационные данные. Повторный запуск не добавляет дубликаты."""
from sqlmodel import Session, select

from app.database.session import engine, init_db
from app.models import Category, Movement, Product, Supplier


def seed():
    init_db()
    with Session(engine) as session:
        categories = {}
        for name in ["Канцелярия", "Электроника", "Упаковка"]:
            item = session.exec(select(Category).where(Category.name == name)).first()
            if item is None:
                item = Category(name=name)
                session.add(item)
                session.flush()
            categories[name] = item.id
        suppliers = {}
        for name in ["Офис Плюс", "ТехноСнаб", "Пакет Сервис"]:
            item = session.exec(select(Supplier).where(Supplier.name == name)).first()
            if item is None:
                item = Supplier(name=name, contact="Учебный поставщик")
                session.add(item)
                session.flush()
            suppliers[name] = item.id
        samples = [
            ("Ручка синяя", "PEN-001", "Канцелярия", "Офис Плюс", 20, 100),
            ("Блокнот A5", "NOTE-001", "Канцелярия", "Офис Плюс", 10, 25),
            ("Мышь USB", "USB-001", "Электроника", "ТехноСнаб", 5, 3),
            ("Коробка картонная", "BOX-001", "Упаковка", "Пакет Сервис", 15, 40),
        ]
        for name, sku, category, supplier, minimum, amount in samples:
            if session.exec(select(Product).where(Product.sku == sku)).first():
                continue
            product = Product(name=name, sku=sku, category_id=categories[category],
                              supplier_id=suppliers[supplier], min_stock=minimum)
            session.add(product)
            session.flush()
            session.add(Movement(product_id=product.id, delta=amount, note="Начальный остаток"))
        session.commit()
    print("Демонстрационные данные готовы: 3 категории, 3 поставщика, 4 товара.")


if __name__ == "__main__":
    seed()
