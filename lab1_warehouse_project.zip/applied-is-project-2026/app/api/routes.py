from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, text
from sqlalchemy.exc import IntegrityError
from sqlmodel import Session, select

from app.api.schemas import CategoryCreate, MovementCreate, ProductCreate, SupplierCreate
from app.database.session import get_session
from app.models import Category, Movement, Product, Supplier

router = APIRouter(prefix="/api")


def save_unique(session, obj, message):
    session.add(obj)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        raise HTTPException(status_code=409, detail=message)
    session.refresh(obj)
    return obj


@router.get("/categories", response_model=list[Category], tags=["Справочники"])
def categories(session: Session = Depends(get_session)):
    return session.exec(select(Category).order_by(Category.id)).all()


@router.post("/categories", response_model=Category, status_code=201, tags=["Справочники"])
def add_category(data: CategoryCreate, session: Session = Depends(get_session)):
    return save_unique(session, Category(**data.model_dump()), "Такая категория уже есть")


@router.get("/suppliers", response_model=list[Supplier], tags=["Справочники"])
def suppliers(session: Session = Depends(get_session)):
    return session.exec(select(Supplier).order_by(Supplier.id)).all()


@router.post("/suppliers", response_model=Supplier, status_code=201, tags=["Справочники"])
def add_supplier(data: SupplierCreate, session: Session = Depends(get_session)):
    return save_unique(session, Supplier(**data.model_dump()), "Такой поставщик уже есть")


@router.get("/products", tags=["Товары"])
def products(session: Session = Depends(get_session)):
    balances = dict(session.exec(
        select(Movement.product_id, func.sum(Movement.delta)).group_by(Movement.product_id)
    ).all())
    rows = session.exec(select(Product, Category.name, Supplier.name)
                        .join(Category).join(Supplier).order_by(Product.id)).all()
    return [dict(**p.model_dump(), category=category, supplier=supplier,
                 stock=int(balances.get(p.id, 0)),
                 low_stock=balances.get(p.id, 0) < p.min_stock)
            for p, category, supplier in rows]


@router.post("/products", response_model=Product, status_code=201, tags=["Товары"])
def add_product(data: ProductCreate, session: Session = Depends(get_session)):
    if not session.get(Category, data.category_id):
        raise HTTPException(status_code=404, detail="Категория не найдена")
    if not session.get(Supplier, data.supplier_id):
        raise HTTPException(status_code=404, detail="Поставщик не найден")
    return save_unique(session, Product(**data.model_dump()), "Этот артикул уже используется")


@router.get("/movements", tags=["Движение товаров"])
def movements(session: Session = Depends(get_session)):
    rows = session.exec(select(Movement, Product.name, Product.sku).join(Product)
                        .order_by(Movement.id.desc())).all()
    return [dict(**m.model_dump(), product=name, sku=sku) for m, name, sku in rows]


@router.post("/movements", response_model=Movement, status_code=201, tags=["Движение товаров"])
def add_movement(data: MovementCreate, session: Session = Depends(get_session)):
    # SQLite блокирует конкурирующую запись до проверки остатка и commit.
    # Иначе два одновременных расхода могли бы потратить один и тот же остаток.
    session.exec(text("BEGIN IMMEDIATE"))
    try:
        if not session.get(Product, data.product_id):
            raise HTTPException(status_code=404, detail="Товар не найден")
        stock = session.exec(select(func.coalesce(func.sum(Movement.delta), 0))
                             .where(Movement.product_id == data.product_id)).one()
        if stock + data.delta < 0:
            raise HTTPException(status_code=409, detail=f"Недостаточно товара. Остаток: {stock}")
        movement = Movement(**data.model_dump())
        session.add(movement)
        session.commit()
        session.refresh(movement)
        return movement
    except Exception:
        session.rollback()
        raise
