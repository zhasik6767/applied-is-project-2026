from pydantic import BaseModel, ConfigDict, Field, field_validator


class InputModel(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")


class CategoryCreate(InputModel):
    name: str = Field(min_length=1, max_length=80)


class SupplierCreate(InputModel):
    name: str = Field(min_length=1, max_length=120)
    contact: str = Field(default="", max_length=120)


class ProductCreate(InputModel):
    name: str = Field(min_length=1, max_length=120)
    sku: str = Field(min_length=1, max_length=40)
    category_id: int = Field(gt=0, strict=True)
    supplier_id: int = Field(gt=0, strict=True)
    min_stock: int = Field(default=5, ge=0, le=1_000_000, strict=True)

    @field_validator("sku")
    @classmethod
    def normalize_sku(cls, value):
        return value.upper()


class MovementCreate(InputModel):
    product_id: int = Field(gt=0, strict=True)
    delta: int = Field(ge=-1_000_000, le=1_000_000, strict=True)
    note: str = Field(default="", max_length=200)

    @field_validator("delta")
    @classmethod
    def nonzero_delta(cls, value):
        if value == 0:
            raise ValueError("Количество не может быть равно нулю")
        return value
