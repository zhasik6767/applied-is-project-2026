"""Проверки правил склада на отдельной временной SQLite-базе."""
import importlib

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import event
from sqlmodel import Session, SQLModel, create_engine

from app.database.session import get_session
from app.main import app


@pytest.fixture
def client(tmp_path, monkeypatch):
    engine = create_engine("sqlite:///" + (tmp_path / "test.db").as_posix(),
                           connect_args={"check_same_thread": False})

    @event.listens_for(engine, "connect")
    def foreign_keys(connection, _):
        connection.execute("PRAGMA foreign_keys=ON")

    SQLModel.metadata.create_all(engine)

    def session_override():
        with Session(engine) as session:
            yield session

    app.dependency_overrides[get_session] = session_override
    monkeypatch.setattr(importlib.import_module("app.main"), "init_db", lambda: None)
    with TestClient(app) as http:
        http.test_engine = engine
        yield http
    app.dependency_overrides.clear()
    engine.dispose()


def product(client):
    category = client.post("/api/categories", json={"name": "Канцелярия"}).json()
    supplier = client.post("/api/suppliers", json={"name": "Поставщик"}).json()
    response = client.post("/api/products", json={"name": "Ручка", "sku": " pen-01 ",
                           "category_id": category["id"], "supplier_id": supplier["id"], "min_stock": 3})
    assert response.status_code == 201
    return response.json()


def test_receipt_expense_and_overspending(client):
    p = product(client)
    assert p["sku"] == "PEN-01"
    assert client.get("/api/products").json()[0]["stock"] == 0
    for delta in [10, -4]:
        assert client.post("/api/movements", json={"product_id": p["id"], "delta": delta}).status_code == 201
    assert client.post("/api/movements", json={"product_id": p["id"], "delta": -7}).status_code == 409
    assert client.get("/api/products").json()[0]["stock"] == 6
    assert len(client.get("/api/movements").json()) == 2
    assert client.post("/api/movements", json={"product_id": p["id"], "delta": -6}).status_code == 201
    row = client.get("/api/products").json()[0]
    assert row["stock"] == 0 and row["low_stock"]


@pytest.mark.parametrize("delta", [0, 1.5, True, 1000001])
def test_invalid_movement(client, delta):
    p = product(client)
    assert client.post("/api/movements", json={"product_id": p["id"], "delta": delta}).status_code == 422
    assert client.get("/api/movements").json() == []


def test_missing_references(client):
    p = product(client)
    body = {"name": "Товар", "sku": "TEST", "category_id": 999, "supplier_id": p["supplier_id"]}
    assert client.post("/api/products", json=body).status_code == 404
    body.update(category_id=p["category_id"], supplier_id=999)
    assert client.post("/api/products", json=body).status_code == 404
    assert client.post("/api/movements", json={"product_id": 999, "delta": 1}).status_code == 404


def test_duplicates_and_empty_names(client):
    p = product(client)
    assert client.post("/api/categories", json={"name": "Канцелярия"}).status_code == 409
    assert client.post("/api/categories", json={"name": "   "}).status_code == 422
    body = {"name": "Другая ручка", "sku": "pen-01", "category_id": p["category_id"], "supplier_id": p["supplier_id"]}
    assert client.post("/api/products", json=body).status_code == 409


def test_seed_is_repeatable(client, monkeypatch):
    from app.database import seed
    monkeypatch.setattr(seed, "engine", client.test_engine)
    monkeypatch.setattr(seed, "init_db", lambda: None)
    seed.seed()
    before = client.get("/api/movements").json()
    seed.seed()
    assert client.get("/api/movements").json() == before
    assert len(client.get("/api/products").json()) == 4
    assert sum(x["stock"] for x in client.get("/api/products").json()) == 168


def test_parallel_expenses_cannot_overdraw(client):
    from concurrent.futures import ThreadPoolExecutor
    p = product(client)
    client.post("/api/movements", json={"product_id": p["id"], "delta": 10})

    def spend(_):
        return client.post("/api/movements", json={"product_id": p["id"], "delta": -7}).status_code

    with ThreadPoolExecutor(max_workers=2) as pool:
        statuses = sorted(pool.map(spend, range(2)))
    assert statuses == [201, 409]
    assert client.get("/api/products").json()[0]["stock"] == 3


def test_health_and_openapi(client):
    assert client.get("/").json()["status"] == "ok"
    assert client.get("/docs").status_code == 200
    assert "/api/products" in client.get("/openapi.json").json()["paths"]
