"""Streamlit обращается к FastAPI по HTTP; прямого доступа к БД здесь нет."""
import os
from pathlib import Path

import httpx
import streamlit as st

API = os.getenv("WAREHOUSE_API_URL", "http://127.0.0.1:8000").rstrip("/")
st.set_page_config(page_title="Склад | Лабораторная 1", page_icon="📦", layout="wide")
st.title("Учёт товаров на складе")
st.caption("Учебный мини-проект • Лабораторная работа 1")


def request(method, path, data=None):
    try:
        response = httpx.request(method, API + path, json=data, timeout=15, trust_env=False)
        if response.is_error:
            detail = response.json().get("detail", "Ошибка запроса")
            if isinstance(detail, list):
                detail = "; ".join(f"{e['loc'][-1]}: {e['msg']}" for e in detail)
            st.error(detail)
            return None
        return response.json()
    except (httpx.HTTPError, ValueError):
        st.error("Нет связи с API. Запустите сервер: python -m uvicorn app.main:app --reload")
        return None


def save(path, data):
    if request("POST", path, data) is not None:
        st.session_state["flash"] = "Запись сохранена"
        st.rerun()


if "flash" in st.session_state:
    st.success(st.session_state.pop("flash"))
if request("GET", "/") is None:
    st.stop()
items = request("GET", "/api/products")
categories = request("GET", "/api/categories")
suppliers = request("GET", "/api/suppliers")
movements = request("GET", "/api/movements")
if any(data is None for data in [items, categories, suppliers, movements]):
    st.stop()

overview, transactions, directories, about = st.tabs(
    ["Остатки", "Приход и расход", "Справочники", "О проекте"]
)

with overview:
    a, b, c = st.columns(3)
    a.metric("Наименований", len(items))
    b.metric("Единиц на складе", sum(x["stock"] for x in items))
    c.metric("Ниже минимума", sum(x["low_stock"] for x in items))
    query = st.text_input("Поиск по названию или артикулу")
    low_only = st.checkbox("Только товары ниже минимального остатка")
    visible = [x for x in items if query.casefold() in (x["name"] + " " + x["sku"]).casefold()
               and (not low_only or x["low_stock"])]
    if visible:
        st.dataframe([{"Артикул": x["sku"], "Товар": x["name"], "Категория": x["category"],
                       "Поставщик": x["supplier"], "Остаток": x["stock"],
                       "Минимум": x["min_stock"],
                       "Статус": "Нужна закупка" if x["low_stock"] else "В норме"}
                      for x in visible], hide_index=True, width="stretch")
    else:
        st.info("Товары не найдены. Добавьте товар или измените поиск.")
    with st.expander("Добавить товар"):
        if not categories or not suppliers:
            st.info("Сначала добавьте категорию и поставщика во вкладке «Справочники».")
        else:
            with st.form("new_product", clear_on_submit=True):
                name = st.text_input("Название товара", max_chars=120)
                sku = st.text_input("Артикул", max_chars=40)
                category = st.selectbox("Категория", categories, format_func=lambda x: x["name"])
                supplier = st.selectbox("Поставщик", suppliers, format_func=lambda x: x["name"])
                minimum = st.number_input("Минимальный остаток", min_value=0, max_value=1000000, value=5)
                if st.form_submit_button("Добавить товар"):
                    save("/api/products", {"name": name, "sku": sku, "category_id": category["id"],
                                           "supplier_id": supplier["id"], "min_stock": minimum})

with transactions:
    if items:
        with st.form("movement", clear_on_submit=True):
            product = st.selectbox("Товар", items, format_func=lambda x: f"{x['sku']} · {x['name']} (остаток {x['stock']})")
            kind = st.radio("Операция", ["Приход", "Расход"], horizontal=True)
            quantity = st.number_input("Количество", min_value=1, max_value=1000000, value=1)
            note = st.text_input("Комментарий", max_chars=200)
            if st.form_submit_button("Сохранить операцию"):
                save("/api/movements", {"product_id": product["id"],
                                        "delta": quantity if kind == "Приход" else -quantity, "note": note})
    else:
        st.info("Сначала добавьте товар.")
    st.subheader("Журнал операций")
    if movements:
        st.dataframe([{"Время UTC": x["created_at"][:19].replace("T", " "), "Артикул": x["sku"],
                       "Товар": x["product"], "Изменение": x["delta"], "Комментарий": x["note"]}
                      for x in movements], hide_index=True, width="stretch")
    else:
        st.info("Операций пока нет.")

with directories:
    left, right = st.columns(2)
    with left:
        st.subheader("Категории")
        st.dataframe([{"ID": x["id"], "Название": x["name"]} for x in categories], hide_index=True)
        with st.form("category", clear_on_submit=True):
            name = st.text_input("Новая категория", max_chars=80)
            if st.form_submit_button("Добавить категорию"):
                save("/api/categories", {"name": name})
    with right:
        st.subheader("Поставщики")
        st.dataframe([{"ID": x["id"], "Название": x["name"], "Контакт": x["contact"]}
                      for x in suppliers], hide_index=True)
        with st.form("supplier", clear_on_submit=True):
            name = st.text_input("Новый поставщик", max_chars=120)
            contact = st.text_input("Контакт", max_chars=120)
            if st.form_submit_button("Добавить поставщика"):
                save("/api/suppliers", {"name": name, "contact": contact})

with about:
    st.write("Streamlit показывает формы и таблицы. FastAPI проверяет запросы. SQLModel описывает таблицы SQLite.")
    st.write("У товара одна категория и один основной поставщик. Остаток равен сумме всех приходов и расходов.")
    st.image(str(Path(__file__).resolve().parents[1] / "docs" / "er_diagram.png"), caption="Четыре сущности и три связи один ко многим")
    st.link_button("Документация API", API + "/docs")
